# This file contains the example and sample codes in the user manual:
#   6       Regression Analysis
#   6.4     Examples
#   6.4.2   Mobility Dynamics

from covemda.integration import City

la = City('la')  # create a City object
la.run_general_var(  # apply the VAR model
    x=la.dfmt_mobility.select_by_column(('grocery', 'restaurant')),
    y=la.dfmt_mobility.select_by_column('retail'),
)

