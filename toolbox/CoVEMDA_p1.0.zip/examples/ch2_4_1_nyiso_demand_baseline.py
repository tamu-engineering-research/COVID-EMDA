# This file contains the example and sample codes in the user manual:
#   2       Getting Started
#   2.4     Quick Start Examples
#   2.4.1   Demand Baseline Estimation

from covemda.integration import RTO

nyiso = RTO('nyiso')  # create a RTO object
print(nyiso.cal_demand_baseline())  # calculate then print out the baseline
nyiso.plot_demand_baseline()  # visualize the baseline

