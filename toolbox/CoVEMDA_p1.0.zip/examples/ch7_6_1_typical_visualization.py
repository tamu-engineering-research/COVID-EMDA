# This file contains the example and sample codes in the user manual:
#   7       Scientific Visualization
#   7.6     Examples
#   7.6.1   Typical Use Cases

import pandas as pd
from covemda.integration import RTO

isone = RTO('isone')  # create RTO objects
nyiso = RTO('nyiso')

isone.plot_price_distribution()  # plot price distribution using data from 2020-01-01 to 2020-06-30
isone.plot_price_distribution(date=pd.date_range('2019-01-01', '2019-06-30'))

nyiso.plot_price_series(date=pd.date_range('2019-01-01', '2019-12-31'))  # plot the price series in 2019

nyiso.plot_demand_series(date=pd.date_range('2020-02-01', '2020-04-30'))  # plot 2 year demand series
nyiso.plot_demand_series(date=pd.date_range('2019-02-01', '2019-04-30'))

