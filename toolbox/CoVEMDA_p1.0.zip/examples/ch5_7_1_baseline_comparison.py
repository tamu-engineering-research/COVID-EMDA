# This file contains the example and sample codes in the user manual:
#   5       Baseline Estimation
#   5.7     Examples
#   5.7.1   Demand Baselines Comparison

import pandas as pd
from covemda.integration import RTO

nyiso = RTO('nyiso')  # create a RTO object
for method in ('date-alignment', 'week-alignment', 'backcast'):  # compare different baselines visually
    nyiso.plot_demand_baseline('2020-04-27', method)

for method in ('date-alignment', 'week-alignment', 'backcast'):  # compare different baselines statistically
    print(f"\nMethod: {method}")
    nyiso.eval_demand_baseline('2020-04-27', method)

print(nyiso.cal_demand_baseline('2020-04-27', method='date-alignment'))  # get baseline values

for date in ('2020-04-27', '2019-04-27'):  # date info, need low-level functions
    dfmt = nyiso.dfmt_demand.select_by_date(after=date, before=date)
    print(dfmt.gen_calendar_data().data)

