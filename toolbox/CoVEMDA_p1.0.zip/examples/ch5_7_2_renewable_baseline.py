# This file contains the example and sample codes in the user manual:
#   5       Baseline Estimation
#   5.7     Examples
#   5.7.2   Renewable Generation Baselines

import pandas as pd
from covemda.integration import RTO

nyiso = RTO('nyiso')  # create a RTO object
for method in ('month-alignment', 'monthly-trend'):
    nyiso.plot_genmix_baseline(pd.date_range('2019-06-30', '2020-06-30'), method)

