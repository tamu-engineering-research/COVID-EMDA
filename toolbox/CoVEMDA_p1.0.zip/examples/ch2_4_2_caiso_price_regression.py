# This file contains the example and sample codes in the user manual:
#   2       Getting Started
#   2.4     Quick Start Examples
#   2.4.2   Regression Analysis for Price

from covemda.integration import RTO

caiso = RTO('caiso')  # create a RTO object
caiso.run_general_ols(  # apply the OLS model
    x=caiso.dfmt_price.select_by_column(('00:00', '01:00')),
    y=caiso.dfmt_price.select_by_column('02:00'),
)

