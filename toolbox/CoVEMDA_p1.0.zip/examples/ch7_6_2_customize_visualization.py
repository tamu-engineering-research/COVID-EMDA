# This file contains the example and sample codes in the user manual:
#   7       Scientific Visualization
#   7.6     Examples
#   7.6.2   Chart Customization

import pandas as pd
from covemda.integration import RTO

nyiso = RTO('nyiso')  # create RTO objects
spp = RTO('spp')

nyiso.plot_price_series(
    date=pd.date_range('2020-03-01', '2020-03-07'),
    config={'price_series': dict(marker='o')},  # set markers at data points
)

new_color = {  # make fossil energy gray
    'coal':    'dimgray',   # changed
    'gas':     'gray',      # changed
    'oil':     'darkgray',  # changed
    'nuclear': 'silver',    # changed
    'hydro':   '#a0d8f1',
    'wind':    '#73c698',
    'solar':   '#ffbd4a',
    'other':   '#b4b4b4',
    'import':  'white',
}
spp.plot_generation_mix()
spp.plot_generation_mix(config={'generation_mix': dict(colormap=new_color)})

