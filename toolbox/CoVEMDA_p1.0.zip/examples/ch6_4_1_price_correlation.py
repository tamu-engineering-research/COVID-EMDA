# This file contains the example and sample codes in the user manual:
#   6       Regression Analysis
#   6.4     Examples
#   6.4.1   Price Correlation Analysis

from covemda.integration import City

phila = City('phila')  # create a City object
phila.test_price_correlation()  # price = k1 * demand + k2 * temperature + k3
phila.cal_correlation_coeff(  # temperature-price correlation
    x=phila.dfmt_weather.select_by_kind('tmpc'),
    y=phila.dfmt_price,
)

