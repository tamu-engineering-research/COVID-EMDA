import sys
from distutils.version import StrictVersion


req = {
    'pandas':       '1.2.4',
    'scipy':        '1.6.2',
    'statsmodels':  '0.12.2',
    'scikit-learn': '0.24.1',
    'matplotlib':   '3.3.4',
}
n_error = 0


print('\n' + '=' * 35)
print('This is a developer-mode install')
print('=' * 35)


print('Checking Python version...')
if sys.version_info < (3, 6):
    print('Error: Require Python >= 3.6.0!')
    n_error += 1


print('Checking Pandas version...')
try:
    import pandas
    if StrictVersion(pandas.__version__) < StrictVersion(req['pandas']):
        print('Error: Require Pandas >= ' + req['pandas'])
        n_error += 1
except ImportError:
    print('Error: Pandas is not installed!')
    n_error += 1


print('Checking Scipy version...')
try:
    import scipy
    if StrictVersion(scipy.__version__) < StrictVersion(req['scipy']):
        print('Error: Require Scipy >= ' + req['scipy'])
        n_error += 1
except ImportError:
    print('Error: Scipy is not installed!')
    n_error += 1


print('Checking Statsmodels version...')
try:
    import statsmodels
    if StrictVersion(statsmodels.__version__) < StrictVersion(req['statsmodels']):
        print('Error: Require Statsmodels >= ' + req['statsmodels'])
        n_error += 1
except ImportError:
    print('Error: Statsmodels is not installed!')
    n_error += 1


print('Checking Scikit-learn version...')
try:
    import sklearn
    if StrictVersion(sklearn.__version__) < StrictVersion(req['scikit-learn']):
        print('Error: Require Scikit-learn >= ' + req['scikit-learn'])
        n_error += 1
except ImportError:
    print('Error: Scikit-learn is not installed!')
    n_error += 1


print('Checking Matplotlib version...')
try:
    import matplotlib
    if StrictVersion(matplotlib.__version__) < StrictVersion(req['matplotlib']):
        print('Error: Require Matplotlib >= ' + req['matplotlib'])
        n_error += 1
except ImportError:
    print('Error: Matplotlib is not installed!')
    n_error += 1


print('Completed. Find %d error(s) in total.' % n_error)


if n_error > 0:
    print('\nPlease configure the environement according to above instructions. After completion, simply copy-and-paste the source codes (in lib/ folder) to the working directory, then import or modify these codes flexbily. Good luck!\n')
else:
    print('\nThe next step is to simply copy-and-paste the source codes (in lib/ folder) to the working directory, then import or modify these codes flexbily. Good luck!\n')


