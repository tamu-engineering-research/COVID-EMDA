print('\nPlease note:')

print('[1] There are no extra operations needed for a developer-mode install, you may drop the codes or data directly, and that\'s done.')

print('[2] For those install by PyPI or .whl file, simply use [pip uninstall covemda] instead.\n')


