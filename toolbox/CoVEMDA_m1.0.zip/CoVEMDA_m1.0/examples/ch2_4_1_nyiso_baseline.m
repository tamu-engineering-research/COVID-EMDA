%   This file contains the examples and sample code in the manual.

%%  2       Getting Started
%   2.4     Illustrative Examples
%   2.4.1   Baseline Estimation with Ensemble Backcast Model

%   Calculate the baseline of NYISO
t = cal_baseline('nyiso')

%   Access data for q=0.5
t.result{3}

%   Visualize the baseline
plot_baseline('nyiso','Method','backcast');
