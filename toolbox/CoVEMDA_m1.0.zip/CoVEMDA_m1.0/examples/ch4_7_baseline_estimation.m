%   This file contains the examples and sample code in the manual.

%%  4       Baseline Estimation
%   4.7     Examples

%   Train a new ensemble backcast model with less networks
t_retrain = cal_baseline('caiso','TrainModel',1,'ModelNum',[10,8])

%   Visualize different baselines
handles = plot_baseline('nyiso','DateRangeCovid','2020-04-01');
handles{6}.Color = '#d95319';

%   Add the observed demand data to the graph
plot_demand('nyiso','DateRange','2020-04-01','DisplayName','observed','Color','#edb120');
ax = gca;
ax.XTickLabel = strcat(string([0:2:22,23]),":00");
