%   This file contains the examples and sample code in the manual.

%%  6       Visualization
%   6.6     Examples
%   6.6.2   Customize Plot Properties

%   Display markers at data points
plot_price('nyiso','DateRange',{'2019-01-01','2019-12-31'},'ResampleBin','month','ResampleMethod','mean','Marker','o');

%   Change the default display range of y-axis
plot_daily_demand_curve('nyiso');
ax = gca;
ax.YLim = [0,4];

%   Highlight renewable energy in a generation mix graph
ar = plot_generation_mix('spp');
ar{1}.FaceColor = '#868686';
ar{2}.FaceColor = '#acacac';
ar{4}.FaceColor = '#7f7f7f';
ar{5}.FaceColor = '#6b6b6b';
