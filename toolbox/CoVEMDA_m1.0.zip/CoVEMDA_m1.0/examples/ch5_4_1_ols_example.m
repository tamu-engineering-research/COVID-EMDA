%   This file contains the examples and sample code in the manual.

%%  5       Regression Analysis
%   5.4     Examples
%   5.4.1   OLS Example

%   Import data in table format
t = basic_read('caiso_la_patterns');

%   Exchange columns of table
t = basic_exchange_columns(t,1,4);

%   Do the regression
b = OLS(t,3,'linear')
