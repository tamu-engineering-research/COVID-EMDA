%   This file contains the examples and sample code in the manual.

%%  2       Getting Started
%   2.3     Illustrative Examples
%   2.3.2   Regression Analysis

%   Read the social distancing data of CAISO
t = basic_read('caiso_rto_lmp');

%   Pre-process data
t = basic_exchange_columns(t,1,4);

%   Apply the OLS model
b = OLS(t,3,'linear')
