%   This file contains the examples and sample code in the manual.

%%  6       Visualization
%   6.6     Examples
%   6.6.1   Basic Usage

%   Plot the price distribution histogram of ISONE
plot_price_distribution('isone');

%   Plot the average price of every month in 2019
plot_price('nyiso','DateRange',{'2019-01-01','2019-12-31'},'ResampleBin','month','ResampleMethod','mean');

%   Plot the demand curves of NYISO in 2018, 2019 and 2020 with date alignment
%   Calculate the corresponding date range
dr_2020 = datetime('2020-2-1'):datetime('2020-4-30');
dr_2019 = dr_2020 - calyears(1);
dr_2018 = dr_2019 - calyears(1);

%   Plot the demand curves
plot_demand('nyiso','DateRange',dr_2018,'DisplayName','2018','LineStyle',':','Color','#939598');
plot_demand('nyiso','DateRange',dr_2019,'DisplayName','2019','LineStyle','--','Color','#D95319');
plot_demand('nyiso','DateRange',dr_2020,'DisplayName','2020','Color','#0072BD','LineWidth',2.5);
