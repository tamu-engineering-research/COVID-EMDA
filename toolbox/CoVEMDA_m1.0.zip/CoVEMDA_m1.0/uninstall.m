function uninstall
    rootdir = mfilename('fullpath');
    filename_length = length(mfilename());
    rootdir(end-filename_length:end) = [];
    rmpath(genpath(rootdir));
    savepath;
end