function t = basic_read(filename)
    % T = basic_read(FILENAME, MARKET)
    %
    % Description:
    % 	Read released data from GitHub. Returns a MATLAB table containing
    % 	the data.
    %
    % Examples:
    % 	mytable = basic_read('caiso_rto_genmix');
    % 	mytable = basic_read('caiso_rto_genmix.csv');
    
    %% Initialize output variables
    t = table;
    
    %% Determine input parameters
    market = strsplit(filename, '_');
    market = market{1};
    if ~contains(filename, '.csv')
        filename = strcat(filename, '.csv');
    end
    
    localdir = strcat(basic_gen_root_dir(), '\data\COVID_EMDA');
    localfile = strcat(localdir, '\', filename);
    
    %% Get data
    web_root = ' https://raw.githubusercontent.com/tamu-engineering-research/COVID-EMDA/master/';
    if exist(localfile, 'file') == 0     %Download data from GitHub
        command_string = strcat('curl -O', web_root, 'data_release/', market, '/', filename);
        [~, ~] = system(command_string);
        movefile(filename, localdir);
    end
    
    t = readtable(localfile, 'PreserveVariableNames', true);
end