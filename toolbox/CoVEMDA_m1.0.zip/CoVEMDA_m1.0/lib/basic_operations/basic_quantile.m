function g = basic_quantile(t, q, axis)
    % G = basic_quantile(T, Q, AXIS)
    %
    % Description:
    % 	Calculate the quantile of the columns or rows.
    %
    % Input:
    %   AXIS: 0(columns) or 1(rows).
    %   Q: quantile to be calculated.
    %
    % Example:
    %   g = basic_quantile(t, 0.5, 0);
    %   g = basic_quantile(t, 0.75, 1);
    
    %% Initialize output variables
    g = table;
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    
    if axis == 0    % Columns
        quant = @(x) quantile(x, q);
        g = varfun(quant, t, 'InputVariables', calc_val);
        g = renamevars(g, g.Properties.VariableNames, calc_val);
    else    % Rows
        others = t(:, keep_val);
        row_q = table2array(t(:, calc_val));
        row_q = quantile(row_q, q, 2);
        g = addvars(others, row_q);
        g = renamevars(g, 'row_q', calc_val{1});
    end
end