function output = basic_exchange_columns(table,column1,column2)
    t2=movevars(table,column1,'Before',column2);
    t3=movevars(t2,column2,'Before',column1);
    output = t3;
end