function g = basic_group(t, method)
    % G = basic_group(T, METHOD)
    %
    % Description:
    % 	Group the table by non-date columns (if exists).
    %
    % Example:
    %   g = basic_group(t, 'sum');
    
    %% Initialize output variables
    g = table;
    
    %% Divide variable names
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');    %Variables to be calculated
    g_head = ['date', calc_val(:)'];
    
    %% Group the table
    g = groupsummary(t, 'date', 'none', method, calc_val);
    
    %% Restore default variable names
    g.GroupCount = [];
    g = renamevars(g, g.Properties.VariableNames, g_head);
end