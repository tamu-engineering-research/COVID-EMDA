function g = basic_max(t, axis)
    % G = basic_max(T, AXIS)
    %
    % Description:
    % 	Calculate the maximum value of all the columns or rows.
    %
    % Input:
    %   AXIS: 0(columns) or 1(rows).
    %
    % Example:
    %   g = basic_max(t, 0);
    %   g = basic_max(t, 1);
    
    %% Initialize output variables
    g = table;
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    if axis == 0    % Columns
        g = varfun(@max, t, 'InputVariables', calc_val);
        g = renamevars(g, g.Properties.VariableNames, calc_val);
    else    % Rows
        others = t(:, keep_val);
        row_max = table2array(t(:, calc_val));
        row_max = max(row_max, [], 2);
        g = addvars(others, row_max);
        g = renamevars(g, 'row_max', calc_val{1});
    end
end