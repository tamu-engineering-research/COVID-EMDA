function [XTrain, YTrain, XValid, YValid] = basic_backcast_split_train_and_valid(t_XTrainandvalid, t_YTrainandvalid)
    %% Split Training and Validation Set
    rand_num = randperm(height(t_XTrainandvalid));
    rand_num = union(rand_num(1:ceil(0.8*numel(rand_num))), find(year(t_XTrainandvalid.date) == 2020));
    rand_num = sort(rand_num);
    remain_num = setdiff(1:height(t_XTrainandvalid), rand_num, 'stable');
    XTrain = table2array(removevars(t_XTrainandvalid(rand_num, :), 'date'))';
    YTrain = table2array(removevars(t_YTrainandvalid(rand_num, :), 'date'))';
    XValid = table2array(removevars(t_XTrainandvalid(remain_num, :), 'date'))';
    YValid = table2array(removevars(t_YTrainandvalid(remain_num, :), 'date'))';
end