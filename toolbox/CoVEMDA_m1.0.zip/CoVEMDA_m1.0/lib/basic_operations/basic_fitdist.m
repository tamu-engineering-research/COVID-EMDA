function g = basic_fitdist(t, distname)
    % G = basic_fitdist(T, DISTNAME)
    %
    % Description:
    % 	Fit probability distribution object to the table
    %
    % Example:
    %   g = basic_fitdist(t, 'Normal');
    
    %% Initialize output variables
    g = table;
    
    
    other_headers = {'date', 'fuel'};
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    head_temp = setdiff(keep_val, 'date');
    
    [~,gn,~] = fitdist(t.(calc_val{1}), distname,'By',t.(head_temp{:}));
    
    if length(keep_val) > 1
        func = @(x) (fitdist(x, distname, 'By', t.(head_temp{:})))';
    else
        func = @(x) (fitdist(x, distname))';
    end

    g = varfun(func, t, 'InputVariables', calc_val);
    g = renamevars(g, g.Properties.VariableNames, calc_val);
    g = addvars(g, gn, 'NewVariableNames', head_temp, 'Before', 1);
end