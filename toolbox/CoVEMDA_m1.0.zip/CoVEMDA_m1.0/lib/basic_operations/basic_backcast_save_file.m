function basic_backcast_save_file(t_net, type, model_dir)
    if ~exist(model_dir, 'dir')
        mkdir(model_dir);
    end
    if strcmp(type, 'summary')
        file_dir = strcat(model_dir, "\Summary.csv");
        others = {'net', 'PSX', 'PSY'};
        t_net = t_net(:, setdiff(t_net.Properties.VariableNames, others, 'stable'));
        writetable(t_net, file_dir);
    elseif strcmp(type, 'modelmat')
        file_dir = strcat(model_dir, "\Models.mat");
        save(file_dir, 't_net');
    elseif strcmp(type, 'modelonnx')
        for model_id = 1:height(t_net)
            file_dir = strcat(model_dir, "\Model_No.", num2str(t_net.id(model_id)), ".onnx");
            exportONNXNetwork(t_net.net(model_id), file_dir);
        end
    end
end