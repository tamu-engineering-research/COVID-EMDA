function t_net = basic_backcast_import_models(type, model_dir)
    if ~strcmp(type, 'manual')
        if strcmp(type, 'latest')
            type = 1;
        end
        dir_info = struct2table(dir(model_dir));
        dir_info = dir_info(dir_info.isdir,:);
        if height(dir_info) == 0
           error("No valid model files found."); 
        end
        dir_info.date = datetime(dir_info.date);
        dir_info = sortrows(dir_info(3:end,:), 'date', 'descend');
        type = min(type, height(dir_info));
        model_dir = strcat(model_dir, "\", dir_info.name(type));
    end
    model_dir = strcat(model_dir, "\Models.mat");
    t_net = load(model_dir);
    t_net = t_net.t_net;
end