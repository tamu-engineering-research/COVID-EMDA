function g = basic_mean(t, axis)
    % G = basic_mean(T, AXIS)
    %
    % Description:
    % 	Get the average value of all the columns or rows.
    %
    % Input:
    %   AXIS: 0(columns) or 1(rows).
    %
    % Example:
    %   g = basic_mean(t, 0);
    %   g = basic_mean(t, 1);
    
    %% Initialize output variables
    g = table;
    
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    if axis == 0    % Columns
        g = varfun(@mean, t, 'InputVariables', calc_val);
        g = renamevars(g, g.Properties.VariableNames, calc_val);
    else   % Rows
        others = t(:, keep_val);
        row_mean = table2array(t(:, calc_val));
        row_mean = mean(row_mean, 2);
        g = addvars(others, row_mean);
        g = renamevars(g, 'row_mean', calc_val{1});
    end
end