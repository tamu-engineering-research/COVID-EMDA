function g = basic_min(t, axis)
    % G = basic_min(T, AXIS)
    %
    % Description:
    % 	Calculate the minimum value of all the columns or rows.
    %
    % Input:
    %   AXIS: 0(columns) or 1(rows).
    %
    % Example:
    %   g = basic_min(t, 0);
    %   g = basic_min(t, 1);
    
    %% Initialize output variables
    g = table;
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    if axis == 0    % Columns
        g = varfun(@min, t, 'InputVariables', calc_val);
        g = renamevars(g, g.Properties.VariableNames, calc_val);
    else    % Rows
        others = t(:, keep_val);
        row_min = table2array(t(:, calc_val));
        row_min = min(row_min, [], 2);
        g = addvars(others, row_min);
        g = renamevars(g, 'row_min', calc_val{1});
    end
end