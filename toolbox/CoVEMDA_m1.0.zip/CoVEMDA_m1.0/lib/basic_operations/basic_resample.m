function g = basic_resample(t, bin, method)
    % G = basic_resample(T, BIN, METHOD)
    %
    % Description:
    % 	Resample the table by 'date' and return the computation specified
    %   in METHOD.
    %
    % Example:
    %   g = basic_resample(t, 'month', 'mean');

    %% Initialize output variables
    g = table;
    if strcmp(bin, 'none')
       g = t;
       return;
    end
    
    %% Divide variable names
    other_headers = {'date', 'fuel'};
    keep_val = intersect(t.Properties.VariableNames, other_headers);    % Variables to be kept the same
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');    %Variables to be calculated
    g_head = [keep_val(:)', calc_val(:)'];  % Variable names of the new table
    
    for i = 2:length(keep_val)
       bin = [bin(:)', {'none'}]; 
    end
    if ischar(bin)
        bin = {bin};
    end
    
    %% Group the table
    g = groupsummary(t, keep_val, bin, method, calc_val);
    
    %% Restore default variable names
    g.GroupCount = [];
    g = renamevars(g, g.Properties.VariableNames, g_head);
    if  ismember(bin{1}, {'day', 'month'})
        g.date = datetime(string(g.date));
    else
        g.date = string(g.date);
    end
end