function g = basic_filter(t, filb, fila)
    % G = basic_filter(T, FILB, FILA)
    %
    % Description:
    % 	Apply the filter in FILB, FILA to the table
    %
    % Example:
    %   g = basic_filter(t);
    %   g = basic_filter(t, 4);
    %   g = basic_filter(t, [1, -1]);
    %   g = basic_filter(t, [1, -1], [1, 1]);
    
    %% Initialize output variables
    g = table;
    
    narginchk(1, 3);
    if nargin == 1
        fila = 1;
        filb = 5;
    elseif nargin == 2
        fila = 1;
    end
    if length(fila) == 1 && length(filb) == 1   % smooth
        filb = (1/filb)*ones(1,filb);
    end
    
    func = @(x) filter(filb, fila, x);
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    g = t(:, keep_val);
    g_temp = varfun(func, t, 'InputVariables', calc_val);
    for names = g_temp.Properties.VariableNames
        g = addvars(g, g_temp.(names{:}));
    end
    g = renamevars(g, g.Properties.VariableNames, [keep_val(:)', calc_val(:)']);
end