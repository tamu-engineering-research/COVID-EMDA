function [net, err, PSX, PSY] = basic_backcast_train_and_validate(XTrain, YTrain, ...
        XValid, YValid, numHiddenUnits, trainverbose)
    [XTrain, PSX] = mapminmax(XTrain);
    [YTrain, PSY] = mapminmax(YTrain);
    XValid = mapminmax('apply', XValid, PSX);
    YValid = mapminmax('apply', YValid, PSY);
    
    %% Determine Network
    numFeatures = size(XTrain, 1);
    numResponses = size(YTrain, 1);
    
    layers = [ ...
        sequenceInputLayer(numFeatures)
        fullyConnectedLayer(numHiddenUnits(1))
        reluLayer
        fullyConnectedLayer(numHiddenUnits(2))
        reluLayer
        fullyConnectedLayer(numResponses)
        regressionLayer];
    
    %% Train Network
    options = trainingOptions('adam', ...
        'MaxEpochs',3000, ...
        'InitialLearnRate',0.005, ...
        'Shuffle','every-epoch', ...
        'MiniBatchSize',256, ...
        'L2Regularization',0.001, ...
        'ValidationData',{XValid, YValid}, ...
        'ValidationPatience',2, ...
        'Verbose',trainverbose>1);
    
    net = trainNetwork(XTrain, YTrain, layers, options);
    
    YPredvalid = predict(net, XValid);
    YValid = mapminmax('reverse', YValid, PSY);
    YPredvalid = mapminmax('reverse', YPredvalid, PSY);
    err = mean(abs((YPredvalid-YValid)./YValid), 'all');
    net = resetState(net);
end