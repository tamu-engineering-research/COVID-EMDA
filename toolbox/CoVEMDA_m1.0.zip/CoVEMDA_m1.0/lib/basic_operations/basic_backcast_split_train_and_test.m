function [t_XTrainandvalid, t_YTrainandvalid, t_XTest, t_YTest] = ...
        basic_backcast_split_train_and_test(dr_Trainandtest, t_XTrainandtest, t_YTrainandtest)
    %% Split Training and Testing Set
    date_test = [];
    for dt = dr_Trainandtest(1):calmonths(1):dr_Trainandtest(end)
        dr_currentmonth = datetime(year(dt), month(dt), 1):datetime(year(dt), month(dt)+1, 1)-1;
        rand_num = randperm(numel(dr_currentmonth));
        date_test = [date_test, dr_currentmonth(rand_num(1:4))];
    end
    date_test = sort(date_test);
    
    t_XTest = t_XTrainandtest(ismember(t_XTrainandtest.date, date_test),:);
    t_YTest = t_YTrainandtest(ismember(t_YTrainandtest.date, date_test),:);
    t_XTrainandvalid = t_XTrainandtest(~ismember(t_XTrainandtest.date, date_test),:);
    t_YTrainandvalid = t_YTrainandtest(~ismember(t_YTrainandtest.date, date_test),:);
end