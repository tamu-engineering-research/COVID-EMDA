function t = basic_plot_preprocess_table(t_in, bin, method)
    while iscell(t_in)
        t_in = t_in{:};
    end
    t = basic_resample(t_in, bin, method);
    if strcmp(bin, 'none')
        other_headers = {'date'};
        calc_val = setdiff(t.Properties.VariableNames, other_headers);
        t = stack(t, calc_val, 'NewDataVariableName', calc_val{1});
        t(:,end-1) = [];
    elseif strcmp(method, 'sum')
        t = basic_sum(t, 1);
    else
        t = basic_mean(t, 1);
    end
end