function root_dir = basic_gen_root_dir()
    rel_len = length('lib\basic_operations\basic_gen_root_dir');
    root_dir = mfilename('fullpath');
    root_dir(end-rel_len:end) = [];
end

