function g = basic_sum(t, axis)
    % G = basic_sum(T, AXIS)
    %
    % Description:
    % 	Sum up all the columns or rows.
    %
    % Input:
    %   AXIS: 0(columns) or 1(rows).
    %
    % Example:
    %   g = basic_sum(t, 0);
    %   g = basic_sum(t, 1);
    
    %% Initialize output variables
    g = table;
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    keep_val = intersect(t.Properties.VariableNames, other_headers);
    if axis == 0    % Columns
        g = varfun(@sum, t, 'InputVariables', calc_val);
        g = renamevars(g, g.Properties.VariableNames, calc_val);
    else    % Rows
        others = t(:, keep_val);
        row_sum = table2array(t(:, calc_val));
        row_sum = sum(row_sum, 2);
        g = addvars(others, row_sum);
        g = renamevars(g, 'row_sum', calc_val{1});
    end
end