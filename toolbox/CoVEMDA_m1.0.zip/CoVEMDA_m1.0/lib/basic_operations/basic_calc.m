function g = basic_calc(t1, t2, op)
    %G = basic_calc(T1, T2, OP)
    %
    % Description:
    % 	Calculation of two tables by elements
    %
    % Input:
    %   OP: 'add', 'sub', 'mul', 'div'.
    %
    % Example:
    %   g = basic_calc(t1, t2, 'add');
    
    %% Initialize output variables
    g = table;
    
    if width(t1) ~= width(t2)
        error('Wrong dimension!');
    end
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t1.Properties.VariableNames, other_headers, 'stable');
    keep_val1 = intersect(t1.Properties.VariableNames, other_headers);
    keep_val2 = intersect(t2.Properties.VariableNames, other_headers);
    if ~isequal(keep_val1, keep_val2)
        error("Wrong dimension!");
    end
    [~, i1, i2] = intersect(t1(:,keep_val1), t2(:,keep_val2));
    t1 = t1(i1,:);  t1 = sortrows(t1, keep_val1);
    t2 = t2(i2,:);  t2 = sortrows(t2, keep_val2);
    
    g = t1;
    if strcmp(op, 'add')
        g{:, calc_val} = t1{:, calc_val} + t2{:, calc_val};
    elseif strcmp(op, 'sub')
        g{:, calc_val} = t1{:, calc_val} - t2{:, calc_val};
    elseif strcmp(op, 'mul')
        g{:, calc_val} = t1{:, calc_val} .* t2{:, calc_val};
    elseif strcmp(op, 'div')
        g{:, calc_val} = t1{:, calc_val} ./ t2{:, calc_val};
    end
end