function h = plot_histogram(t, varargin)
    % H = plot_histogram(T, VARARGIN)
    %
    % Description:
    % 	Plot a histogram.
    %
    % Input:
    %   T: A table with the second variable to be plotted.
    %   VARARGIN: See also Histogram.
    %
    % Example:
    %   plot_histogram(t);
    %   plot_histogram(t, 'Normalization', 'count');
    
    if ismember('DisplayName', varargin(1:2:length(varargin)))
        index = find(strcmp('DisplayName', varargin), 1);
        dis_name = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        dis_name = t.Properties.VariableNames{2};
    end
    if ismember('Normalization', varargin(1:2:length(varargin)))
        index = find(strcmp('Normalization', varargin), 1);
        normalization = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        normalization = 'pdf';
    end
    if ismember('EdgeColor', varargin(1:2:length(varargin)))
        index = find(strcmp('EdgeColor', varargin), 1);
        edgecolor = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        edgecolor = 'none';
    end
    if ismember('NumBins', varargin(1:2:length(varargin)))
        index = find(strcmp('NumBins', varargin), 1);
        numbins = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        numbins = 50;
    end
    
    %% Plot
    hold on;
    h = histogram(t{:, 2}, 'Normalization', normalization, ...
        'EdgeColor', edgecolor, 'NumBins', numbins, 'DisplayName', dis_name);
    h = {h};
    
    xlim([min(t{:,2}), max(t{:,2})]);
    ax = gca;
    ax.FontName = 'Arial';
    ax.FontSize = 10;
    ax.Box = 'off';
    lgd = legend;
    lgd.Location = 'southoutside';
    lgd.Orientation = 'horizontal';
    lgd.Box = 'off';
    lgd.FontSize = ax.FontSize;
    hold off;
end