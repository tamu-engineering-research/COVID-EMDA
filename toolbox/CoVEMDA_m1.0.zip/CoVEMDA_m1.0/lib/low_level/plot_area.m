function ar = plot_area(t, varargin)
    % AR = plot_area(T, VARARGIN)
    %
    % Description:
    % 	Plot an area.
    %
    % Input:
    %   T: A table with all variables to be plotted.
    %   VARARGIN: COLORMAP: A table/cell/array/struct containing the colors
    %             Others:   See also Area.
    %
    % Example:
    %   plot_area(t);
    %   plot_area(t, 'ColorMap', ColorMap);
    
    %% Modify default parameters
    if ismember('EdgeColor', varargin(1:2:length(varargin)))
        index = find(strcmp('EdgeColor', varargin), 1);
        edgecolor = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        edgecolor = 'none';
    end
    %% Get ColorMap
    if ismember('ColorMap', varargin(1:2:length(varargin)))
        index = find(strcmp('ColorMap', varargin), 1);
        ColorMap = varargin{index+1};
        varargin([index, index+1]) = [];
        if iscell(ColorMap)
            ColorMap = cell2table(ColorMap(2,:), 'VariableNames', ColorMap(1,:));
            ColorMap = convertvars(ColorMap, 1:width(ColorMap), 'string');
        elseif isstruct(ColorMap)
            ColorMap = struct2table(ColorMap);
        elseif ~istable(ColorMap)
            ColorMap = array2table(ColorMap(2,:), 'VariableNames', ColorMap(1,:));
        end
    else
        ColorMap = ["coal",    "#a67a6d";
            "gas",     "#f69850";
            "oil",     "#b35711";
            "nuclear", "#3f9b98";
            "hydro",   "#a0d8f1";
            "wind",    "#73c698";
            "solar",   "#ffbd4a";
            "other",   "#b4b4b4";
            "import",  "white"]';
        ColorMap = array2table(ColorMap(2,:), 'VariableNames', ColorMap(1,:));
    end
    
    %% Normalize
    other_headers = {'date'};
    all_kinds = setdiff(t.Properties.VariableNames, other_headers, 'stable');
    t{:,all_kinds} = t{:,all_kinds} ./ sum(t{:,all_kinds}, 2);
    
    %% Plot
    hold on;
    ar = area(t{:, 2:end}, 'EdgeColor', edgecolor);
    for k = 1:length(all_kinds)
        ar(k).DisplayName = all_kinds{k};
        ar(k).FaceColor = ColorMap{:,all_kinds{k}};
    end
    ar = num2cell(ar);
    
    ticknum = 7;
    if height(t) <= ticknum
        interval = 1;
    else
        interval = round(height(t) / ticknum);
    end
    labelindex = 1:interval:height(t);
    if labelindex(end) ~= height(t)
        labelindex = [labelindex, height(t)];
    end
    labels = string(datestr(t{:,1}, 'yyyy-mmmm', 'local'));
    xlim([1, height(t)]);
    xticks(labelindex);
    xticklabels(labels(labelindex));
    xtickangle(40);
    ylim([0, 1]);
    yticks(0:0.2:1);
    yticklabels(0:20:100);
    ax = gca;
    ax.FontName = 'Arial';
    ax.FontSize = 10;
    ax.Box = 'off';
    lgd = legend;
    lgd.Location = 'southoutside';
    lgd.Orientation = 'horizontal';
    lgd.Box = 'off';
    lgd.FontSize = ax.FontSize;
    hold off;
end