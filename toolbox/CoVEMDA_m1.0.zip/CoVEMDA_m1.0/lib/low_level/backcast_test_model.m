function [t_net_all, t_net_sel] = backcast_test_model(t_net_all, t_XTest, t_YTest, model_sel, varargin)
    if ismember('TrainVerbose', varargin(1:2:length(varargin)))
        index = find(strcmp('TrainVerbose', varargin), 1);
        trainverbose = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        trainverbose = 1;
    end
    
    model_num = height(t_net_all);
    XTest = table2array(removevars(t_XTest, 'date'))';
    YTest = table2array(removevars(t_YTest, 'date'))';
    err_test = zeros(model_num, 1);
    if trainverbose > 0
        disp(strcat("Testing, ", num2str(model_num), " models in total."));
    end
    for model_id = 1:model_num
        if trainverbose > 0
            disp(strcat("--Running Model #", num2str(t_net_all.id(model_id)), "."));
        end
        err_test(model_id) = model_predict(t_net_all.net(model_id), ...
            XTest, YTest, t_net_all.PSX(model_id), t_net_all.PSY(model_id));
    end
    
    t_net_all = addvars(t_net_all, err_test);
    t_net_all = sortrows(t_net_all, 'err_test');
    t_net_sel = t_net_all(1:model_sel, :);
    t_net_all = addvars(t_net_all, ismember(t_net_all.id, t_net_sel.id), 'NewVariableNames', 'selected');
end

function err = model_predict(net, XTest, YTest, PSX, PSY)
    XTest = mapminmax('apply', XTest, PSX);
    YPred = predict(net, XTest);
    YPred = mapminmax('reverse', YPred, PSY);
    err = mean(abs((YPred-YTest)./YTest), 'all');
end