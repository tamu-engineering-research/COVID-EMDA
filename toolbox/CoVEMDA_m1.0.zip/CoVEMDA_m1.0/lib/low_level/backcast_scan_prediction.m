function t_YPreds = backcast_scan_prediction(t_net, t_XPred, varargin)
    if ismember('Quantile', varargin(1:2:length(varargin)))
        index = find(strcmp('Quantile', varargin), 1);
        q = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        q = [0.1, 0.25, 0.5, 0.75, 0.9];
    end
    if ismember('PredictVerbose', varargin(1:2:length(varargin)))
        index = find(strcmp('PredictVerbose', varargin), 1);
        predictverbose = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        predictverbose = 1;
    end
    
    if size(q, 1) == 1
        q = q';
    end
    yheaders = strcat(string(0:23), ":00");
    model_num = height(t_net);
    XPred = table2array(removevars(t_XPred, 'date'))';
    YPredtmp = zeros(size(XPred, 2), length(yheaders), model_num);
    ids = zeros(model_num);
    if predictverbose > 0
        disp(strcat("Predicting, ", num2str(model_num), " models in total."));
    end
    for model_id = 1:model_num
        if predictverbose > 0
            disp(strcat("--Running Model #", num2str(t_net.id(model_id)), "."));
        end
        YPredtmp(:,:,model_id) = model_predict(t_net.net(model_id), ...
            XPred, t_net.PSX(model_id), t_net.PSY(model_id))';
        ids(model_id) = t_net.id(model_id);
    end
    YPred = quantile(YPredtmp, q, 3);
    t_YPreds = {};
    for k = 1:24
        if strlength(yheaders(k)) == 4
            yheaders(k) = strcat("0", yheaders(k));
        end
    end
    for k = 1:length(q)
        t_YPred = array2table(YPred(:,:,k), 'VariableNames', yheaders);
        t_YPred = addvars(t_YPred, t_XPred.date, 'Before', 1, 'NewVariableNames', 'date');
        t_YPreds{k} = t_YPred;
    end
    if length(q) == 1
        t_YPreds = t_YPreds{1};
    else
        t_YPreds = cell2table(t_YPreds', 'VariableNames', "result");
        t_YPreds = addvars(t_YPreds, q, 'NewVariableNames', "quantile", 'Before', 1);
    end
end

function YPred = model_predict(net, XTest, PSX, PSY)
    XTest = mapminmax('apply', XTest, PSX);
    YPred = predict(net, XTest);
    YPred = mapminmax('reverse', YPred, PSY);
end