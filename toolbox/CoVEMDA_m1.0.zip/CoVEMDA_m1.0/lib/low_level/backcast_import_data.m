function [t_XTrainandtest, t_YTrainandtest, t_XTrainandvalid, ...
        t_YTrainandvalid, t_XTest, t_YTest] = ...
        backcast_import_data(market, dr_Trainandtest, varargin)
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    
    gdp_dir = strcat(basic_gen_root_dir(), '\data\backcast\supplementary\gdp.csv');
    %% Import Data
    t_load = basic_read(strcat(market, '_', suf, '_load'));
    % t_load = renamevars(basic_mean(t_load, 1), '00:00', 'load');
    
    t_gdp = readtable(gdp_dir, 'PreserveVariableNames', true);
    if strcmp(suf, 'rto')
        t_gdp = renamevars(t_gdp(:, {'date', market}), market, 'gdp');
    else
        t_gdp = renamevars(t_gdp(:, {'date', suf}), suf, 'gdp');
    end
    
    t_weather = basic_read(strcat(market, '_', suf, '_weather'));
    t_temp = removevars(t_weather(ismember(t_weather.kind, 'tmpc'), :), 'kind');
    t_humid = removevars(t_weather(ismember(t_weather.kind, 'relh'), :), 'kind');
    t_wind = removevars(t_weather(ismember(t_weather.kind, 'sped'), :), 'kind');
    
    holiday = holidays(t_temp.date(1), t_temp.date(end));
    
    t_X = t_temp(:, {'date'});
    t_X.month_day = month(t_X.date) + day(t_X.date) / 31;
    t_X.weekday = double(isweekend(t_X.date));
    t_X.holiday = double(ismember(t_X.date, holiday));
    t_X = innerjoin(t_X, t_gdp, 'Keys', 'date');
    t_X = innerjoin(t_X, renamevars(basic_max(t_temp, 1), '00:00', 'max_temp'), 'Keys', 'date');
    t_X.max_temp2 = t_X.max_temp.^2;
    t_X = innerjoin(t_X, renamevars(basic_mean(t_temp, 1), '00:00', 'mean_temp'), 'Keys', 'date');
    t_X.mean_temp2 = t_X.mean_temp.^2;
    t_X = innerjoin(t_X, renamevars(basic_quantile(t_temp, 0.75, 1), '00:00', 'q75_temp'), 'Keys', 'date');
    t_X = innerjoin(t_X, renamevars(basic_quantile(t_temp, 0.25, 1), '00:00', 'q25_temp'), 'Keys', 'date');
    t_X = innerjoin(t_X, renamevars(basic_max(t_humid, 1), '00:00', 'max_humid'), 'Keys', 'date');
    t_X = innerjoin(t_X, renamevars(basic_mean(t_humid, 1), '00:00', 'mean_humid'), 'Keys', 'date');
    t_X = innerjoin(t_X, renamevars(basic_mean(t_wind, 1), '00:00', 'mean_wind'), 'Keys', 'date');
    t_X = rmmissing(t_X);
    
    t_Y = t_load(ismember(t_load.date, t_X.date), :);
    t_X = t_X(ismember(t_X.date, t_Y.date), :);
    t_XTrainandtest = t_X(ismember(t_X.date, dr_Trainandtest), :);
    t_YTrainandtest = t_Y(ismember(t_Y.date, dr_Trainandtest), :);
    
    [t_XTrainandvalid, t_YTrainandvalid, t_XTest, t_YTest] = ...
        basic_backcast_split_train_and_test(dr_Trainandtest, t_XTrainandtest, t_YTrainandtest);
end