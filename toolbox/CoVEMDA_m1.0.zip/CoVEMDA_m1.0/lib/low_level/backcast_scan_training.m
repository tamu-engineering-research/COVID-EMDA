function t_net = backcast_scan_training( ...
        t_XTrainandvalid, t_YTrainandvalid, model_num, varargin)
    if ismember('numHiddenUnits', varargin(1:2:length(varargin)))
        index = find(strcmp('numHiddenUnits', varargin), 1);
        init_numHiddenUnits = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        init_numHiddenUnits = [32, 64];
    end
    if ismember('TrainVerbose', varargin(1:2:length(varargin)))
        index = find(strcmp('TrainVerbose', varargin), 1);
        trainverbose = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        trainverbose = 1;
    end
    if ismember('RandVariation', varargin(1:2:length(varargin)))
        index = find(strcmp('RandVariation', varargin), 1);
        randvar = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        randvar = 0.2;
    end
    
    if size(init_numHiddenUnits, 1) ~= 1
        init_numHiddenUnits = init_numHiddenUnits';
    end
    nets = [];  nHUs = zeros(model_num, length(init_numHiddenUnits));
    errs = zeros(model_num, 1);  PSXs = [];  PSYs = [];
    if trainverbose > 0
        disp(strcat("Training, ", num2str(model_num), " models in total."));
    end
    for model_id = 1:model_num
        numHiddenUnits = round(init_numHiddenUnits .* (rand(1,2)*2*randvar+1-randvar));
        if trainverbose > 0
            disp(strcat("--Training Model #", num2str(model_id), ...
                ", number of hidden units: ", num2str(numHiddenUnits), "."));
        end
        [XTrain, YTrain, XValid, YValid] = basic_backcast_split_train_and_valid(t_XTrainandvalid, t_YTrainandvalid);
        [net_tmp, err_tmp, PSX_tmp, PSY_tmp] = basic_backcast_train_and_validate(XTrain, YTrain, ...
            XValid, YValid, numHiddenUnits, trainverbose);
        if trainverbose > 0
            disp(strcat("--Model #", num2str(model_id), " trained, MAPE: ", num2str(err_tmp*100, '%.2f'), "%"));
        end
        nets = [nets; net_tmp];
        nHUs(model_id, :) = numHiddenUnits;
        errs(model_id) = err_tmp;
        PSXs = [PSXs; PSX_tmp];
        PSYs = [PSYs; PSY_tmp];
    end
    t_net = table((1:model_num)', nets, nHUs, errs, PSXs, PSYs, ...
        'VariableNames', {'id', 'net', 'numhiddenunits', 'err_valid', 'PSX', 'PSY'});
end