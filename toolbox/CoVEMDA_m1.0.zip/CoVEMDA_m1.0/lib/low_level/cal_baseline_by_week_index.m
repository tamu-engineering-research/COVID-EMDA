function t_output = cal_baseline_by_week_index(market, dr_Covid, varargin)
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    
    year_num = year(dr_Covid) - 1;
    week_num = week(dr_Covid);
    day_num = day(dr_Covid, 'dayofweek');
    
    result_range = datetime(year_num, 1, 1);
    result_range = result_range + 7*(week_num - week(result_range)) + day_num - day(result_range, 'dayofweek');
    
    t_output = basic_read(strcat(market, '_', suf, '_load'));
    t_output = t_output(ismember(t_output.date, result_range),:);
    dr_Covid = dr_Covid(ismember(t_output.date, result_range));
    t_output.date = dr_Covid';
end