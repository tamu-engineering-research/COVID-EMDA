function p = plot_line_chart(t, varargin)
    % P = plot_line_chart(T, VARARGIN)
    %
    % Description:
    % 	Plot a line.
    %
    % Input:
    %   T: A table whose first two columns are to be plotted.
    %   VARARGIN: See also plot.
    % Example:
    %
    %   plot_line_chart(t);
    %   plot_line_chart(t, 'DisplayName', '2020', 'LineWidth', 2.5);
    
    %% Modify default parameters
    if ismember('DisplayName', varargin(1:2:length(varargin)))
        index = find(strcmp('DisplayName', varargin), 1);
        dis_name = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        dis_name = t.Properties.VariableNames{2};
    end
    if ismember('Color', varargin(1:2:length(varargin)))
        index = find(strcmp('Color', varargin), 1);
        Color = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        Color = [];
    end
    if ismember('LineWidth', varargin(1:2:length(varargin)))
        index = find(strcmp('LineWidth', varargin), 1);
        linewidth = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        linewidth = 1;
    end
    if ismember('LineStyle', varargin(1:2:length(varargin)))
        index = find(strcmp('LineStyle', varargin), 1);
        linestyle = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        linestyle = '-';
    end
    if ismember('Marker', varargin(1:2:length(varargin)))
        index = find(strcmp('Marker', varargin), 1);
        marker = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        marker = 'none';
    end
    
    
    %% Plot
    hold on;
    if isempty(Color)
        p = plot(t{:,2}, 'DisplayName', dis_name, 'LineWidth', linewidth, 'LineStyle', linestyle, 'Marker', marker);
    else
        p = plot(t{:,2}, 'DisplayName', dis_name, 'LineWidth', linewidth, 'LineStyle', linestyle, 'Marker', marker, 'Color', Color);
    end
    p = {p};
    
    ticknum = 12;
    if height(t) <= ticknum
        interval = 1;
    else
        interval = floor(height(t) / ticknum);
    end
    labelindex = 1:interval:height(t);
    if labelindex(end) ~= height(t)
        labelindex = [labelindex, height(t)];
    end
    labels = string(t{:,1});
    xlim([1, height(t)]);
    xticks(labelindex);
    xticklabels(labels(labelindex));
    xtickangle(40);
    ytickformat('%.2f');
    ax = gca;
    ax.FontName = 'Arial';
    ax.FontSize = 10;
    ax.Box = 'off';
    lgd = legend;
    lgd.Location = 'southoutside';
    lgd.Orientation = 'horizontal';
    lgd.Box = 'off';
    lgd.FontSize = ax.FontSize;
    hold off;
end

