function t_YPreds = cal_baseline_by_backcast(market, dr_Covid, varargin)
    %% General
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    
    %% Do not train, import existing models
    if ismember('ImportNum', varargin(1:2:length(varargin)))
        index = find(strcmp('ImportNum', varargin), 1);
        import_num = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        import_num = 'latest';
    end
    
    %% Or train the models
    if ismember('TrainModel', varargin(1:2:length(varargin)))
        index = find(strcmp('TrainModel', varargin), 1);
        train = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        train = 0;
    end
    if ismember('DateRangeTrain', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRangeTrain', varargin), 1);
        dr_Trainandtest = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        dr_Trainandtest = datetime('2018-02-01'):datetime('2020-01-31');
    end
    if ismember('ModelNum', varargin(1:2:length(varargin)))
        index = find(strcmp('ModelNum', varargin), 1);
        model_num = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        model_num = [800, 200];
    end
    
    %% Save model and summary
    if ismember('SaveModel', varargin(1:2:length(varargin)))
        index = find(strcmp('SaveModel', varargin), 1);
        savemodel = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        savemodel = 1;
    end
    if ismember('SaveModelONNX', varargin(1:2:length(varargin)))
        index = find(strcmp('SaveModelONNX', varargin), 1);
        savemodelonnx = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        savemodelonnx = 0;
    end
    if ismember('SaveSummary', varargin(1:2:length(varargin)))
        index = find(strcmp('SaveSummary', varargin), 1);
        savesummary = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        savesummary = 1;
    end
    
    
    if ~isdatetime(dr_Trainandtest)
        dr_Trainandtest = datetime(dr_Trainandtest);
    end
    if length(dr_Trainandtest) == 2
        dr_Trainandtest = dr_Trainandtest(1):dr_Trainandtest(2);
    end
    
    
    model_dir = strcat(basic_gen_root_dir(), "\data\backcast\models\", market, "_", suf);
    
    if train ~= 0
        %% Train model
        [~, ~, t_XTrainandvalid, t_YTrainandvalid, t_XTest, t_YTest] = ...
            backcast_import_data(market, dr_Trainandtest, varargin{:});
        
        t_net_all = backcast_scan_training(t_XTrainandvalid, t_YTrainandvalid, ...
            model_num(1), varargin{:});
        [t_net_all, t_net_sel] = backcast_test_model(t_net_all, t_XTest, t_YTest, ...
            model_num(2), varargin{:});
        
        %% Save model and summary
        model_folder = replace(strcat("\Models_", string(datetime('now'))), [" ", ":", "-"], "");
        model_dir = strcat(model_dir, model_folder);
        if savemodel ~= 0
            basic_backcast_save_file(t_net_sel, 'modelmat', model_dir);
        end
        if savemodelonnx ~= 0
            basic_backcast_save_file(t_net_sel, 'modelonnx', model_dir);
        end
        if savesummary ~= 0
            basic_backcast_save_file(t_net_all, 'summary', model_dir);
        end
    else
        %% Import model
        t_net_sel = basic_backcast_import_models(import_num, model_dir);
    end
    
    %% Predict
    t_XCovid = backcast_import_data(market, dr_Covid, varargin{:});
    t_YPreds = backcast_scan_prediction(t_net_sel, t_XCovid, varargin{:});
end