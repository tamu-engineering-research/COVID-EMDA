function gr_handles = plot_quantile(t, varargin)
    % GR_HANDLES = plot_quantile(T, VARARGIN)
    %
    % Description:
    % 	Plot the quantile trend.
    %
    % Input:
    %   T: A table whose variables are different quantiles.
    %   VARARGIN: COLOR: Color of the graph.
    %             ALPHA: Transparency of different quantiles.
    %             LINEWIDTH: Width of the central line(if exists).
    %
    % Example:
    %   plot_quantile(t);
    %   plot_quantile(t, 'Color', '#0072BD', 'Alpha', [0.1, 0.25], 'LineWidth', 2.5);
    
    %% Get parameters
    if ismember('Color', varargin(1:2:length(varargin)))
        index = find(strcmp('Color', varargin), 1);
        Color = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        Color = '#0072BD';
    end
    if ismember('Alpha', varargin(1:2:length(varargin)))
        index = find(strcmp('Alpha', varargin), 1);
        Alpha = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        Alpha = [0.1, 0.25];
    end
    if ismember('LineWidth', varargin(1:2:length(varargin)))
        index = find(strcmp('LineWidth', varargin), 1);
        Width = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        Width = 1;
    end
    
    if Alpha(1) ~= 0
        Alpha = [0, Alpha];
    end
    
    %% Odd or even
    if mod(width(t), 2) == 1
        t_temp = t;
        if Alpha(end) ~= 1
            Alpha = [Alpha, 1, flip(Alpha)];
        else
            Alpha = [Alpha, flip(Alpha(1:end-1))];
        end
    else
        mid = 1+width(t)/2;
        mid_data = t{:, mid};
        t_temp = t(:, [1:mid-1, mid+1:end]);
        Alpha = [Alpha, flip(Alpha(1:end-1))];
    end
    
    other_headers = {'date', 'time'};
    all_kinds = setdiff(t_temp.Properties.VariableNames, other_headers, 'stable');
    disname{1} = "";
    for k = 2:length(all_kinds)
        disname{k} = strcat(all_kinds{k-1},"~",all_kinds{k});
    end
    
    gr_handles = {};
    %% Plot
    hold on;
    for k = flip(3:width(t_temp))
        t_temp{:, k} = t_temp{:, k} - t_temp{:, k-1};
    end
    ar = area(t_temp{:, 2:end});
    for k = 1:length(ar)
        ar(k).FaceColor = Color;
        ar(k).FaceAlpha = Alpha(k);
        ar(k).EdgeColor = 'none';
        ar(k).DisplayName = disname{k};
    end
    gr_handles = [gr_handles, num2cell(ar)];
    if mod(width(t), 2) == 0
        p = plot(mid_data, 'Color', Color, 'LineWidth', Width, 'DisplayName', t.Properties.VariableNames{mid});
        gr_handles = [gr_handles, num2cell(p)];
    end
    
    ticknum = 10;
    if height(t) <= ticknum
        interval = 1;
    else
        interval = floor(height(t) / ticknum);
    end
    labelindex = 1:interval:height(t);
    if labelindex(end) ~= height(t)
        labelindex = [labelindex, height(t)];
    end
    labels = string(t{:,1});
    xlim([1, height(t)]);
    xticks(labelindex);
    xticklabels(labels(labelindex));
    xtickangle(40);
    ylim([1.5*min(t{:, 2})-0.5*mean(t{:, 2}), 1.5*max(t{:, end})-0.5*mean(t{:, end})]);
    ax = gca;
    ax.FontName = 'Arial';
    ax.FontSize = 10;
    ax.Box = 'off';
    lgd = legend;
    lgd.Location = 'southoutside';
    lgd.Orientation = 'horizontal';
    lgd.Box = 'off';
    lgd.FontSize = ax.FontSize;
    hold off;
end