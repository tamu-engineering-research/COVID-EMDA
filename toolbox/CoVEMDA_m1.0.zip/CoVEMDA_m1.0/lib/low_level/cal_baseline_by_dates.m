function t_output = cal_baseline_by_dates(market, dr_Covid, varargin)
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    
    result_range = dr_Covid - calyears(1);
    
    t_output = basic_read(strcat(market, '_', suf, '_load'));
    t_output = t_output(ismember(t_output.date, result_range),:);
    dr_Covid = dr_Covid(ismember(t_output.date, result_range));
    t_output.date = dr_Covid';
end