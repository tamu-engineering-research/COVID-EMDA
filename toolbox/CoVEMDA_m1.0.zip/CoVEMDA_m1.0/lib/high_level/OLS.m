function output = OLS(table, varnum, varargin)
    format short g;
    
    %% define model: 'linear' or 'interaction' or 'quadratic' or 'purequadratic'
    if ismember('model', varargin(1:2:length(varargin)))
        index = find(strcmp('model', varargin), 1);
        model = varargin{index+1};
    else
        model = 'linear';
    end
    
    %% read data
    time1 = clock;
    
    %% define variables
    m = size(table2array(table(:,1)),1);
    X = zeros(m,varnum);
    for i = 1:varnum
        X(:,i) = table2array(table(:,i));
    end
    Y = X(:,1);
    X(:,1) = [];
    
    %% regression
    stats = regstats(Y,X,model);
    
    %% output table
    time2 = clock;
    
    %% prepare values
    date=datestr(now);
    time=etime(time2,time1);
    ttest=[stats.tstat.beta stats.tstat.se stats.tstat.t stats.tstat.pval];
    
    %% output
    fprintf('               OLS Regerssion Results \n');
    fprintf('====================================================\n');
    fprintf('           Model:                      OLS\n');
    fprintf('           Method:           Least Squares\n');
    fprintf('           Date:      %s\n', date);
    fprintf('           Time:                   %0.3f s\n',time);
    fprintf('           R-squared:                %0.3f\n',stats.rsquare);
    fprintf('           Adj. R-squared:           %0.3f\n',stats.adjrsquare);
    fprintf('           F-statistic:              %2.2f\n',stats.fstat.f);
    fprintf('           Prob (F-statistic):       %1.3f\n',stats.fstat.pval);
    fprintf('====================================================\n');
    fprintf('        coef        std err        t         P>|t|      \n');
    disp(ttest);
    output = stats.beta;
end
