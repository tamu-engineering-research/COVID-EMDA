function output = cal_abnormal_price_index(market, varargin)
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = {'2020-03-01', '2020-07-15'};
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    
    filename = strcat(market, '_', suf, '_lmp');
    t = basic_read(filename);
    
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers);
    t = stack(t, calc_val, 'NewDataVariableName', 'Lmp');
    t.Lmp_Indicator = [];
    
    t_target = t(ismember(t.date, date_range),:);
    t_hist = t(t.date < min(date_range),:);
    output = t_target(:, 1);    output.abnormal_index = zeros(height(output), 1);
    
    hist_month_lmps = cell(12, 2);
    
    for m = 1:12
       hist_month_lmps{m,1} = t_hist{month(t_hist.date) == m,2};
       hist_month_lmps{m,2} = length(hist_month_lmps{m,1});
    end
    
    for index = 1:height(output)
        dt = t_target{index, 1};
        lmp = t_target{index, 2};
        
        quantile = sum(hist_month_lmps{month(dt),1} < lmp) / hist_month_lmps{month(dt),2};
        output{index, 'abnormal_index'} = abs(2*quantile-1);
    end
end