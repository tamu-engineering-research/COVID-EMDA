function VAR(table,varnum,order)
    format short g;
    
    %% define variables
    m = size(table2array(table(:,1)),1);
    X = zeros(m,varnum);
    for i = 1:varnum
        X(:,i) = table2array(table(:,i));
    end
    
    
    %% prepare output
    date = datestr(now);
    fprintf('               OLS Regerssion Results \n');
    fprintf('====================================================\n');
    fprintf('           Model:                      VAR\n');
    fprintf('           Method:           Least Squares\n');
    fprintf('           Date:      %s\n', date);
    fprintf('====================================================\n');
    
    
    %% regression and output
    for i = 1:varnum
        Z = [];
        for j = 1:order
            Y = [ones(j,varnum); X(1:m-j,:)];
            Z = [Z, Y];
        end
        
        stats = regstats(X(:,i), Z, 'linear');
        ttest = [stats.tstat.beta stats.tstat.se stats.tstat.t stats.tstat.pval];
        fprintf('        coef        std err         t         P>|t|     \n');
        disp(ttest)
        fprintf('\n');
        
    end
end

