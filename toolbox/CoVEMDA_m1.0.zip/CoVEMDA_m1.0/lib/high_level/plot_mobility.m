function p = plot_mobility(market, varargin)
    % P = plot_mobility(MARKET, VARARGIN)
    %
    % Description:
    % 	Plot the mobility pattern curve of the specified city.
    %
    % Input:
    %   VARARGIN: DATERANGE: Date range. Default {'2017-01-01', '2020-07-15'}.
    %             SECTOR: The sector to be plotted. Default 'Retail'.
    %             RESAMPLEBIN: The bin to resample data. Default 'none'.
    %             RESAMPLEMETHOD: The method to resample data. Default 'mean'.
    %             Others: See also plot_line_chart.
    %
    % Example:
    %   plot_mobility('nyiso');
    %   plot_mobility('nyiso', 'City', 'nyc', 'Sector', 'Grocery_Pharmacy');
    %   plot_mobility('nyiso', 'DateRange', {'2020-02-01', '2020-04-30'});
    %   plot_mobility('nyiso', 'ResampleBin', 'month', 'ResampleMethod', 'sum');
    %   plot_mobility('nyiso', 'DisplayName', '2020', 'LineStyle', '-',
    %                 'Color', '#0072BD', 'LineWidth', 2.5);
    
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = {'2019-12-30', '2020-11-22'};
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = [];
    end
    
    if isempty(suf)
        market_table = ["caiso", "la";
            "ercot", "houston";
            "isone", "boston";
            "nyiso", "nyc";
            "pjm", "chicago";
            % "pjm", "phila";
            "spp", "kck"]';
        market_table = array2table(market_table(2,:), 'VariableNames', market_table(1,:));
        suf = market_table{:, market};
    end
    
    if ismember('Sector', varargin(1:2:length(varargin)))
        index = find(strcmp('Sector', varargin), 1);
        sector = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        sector = 'Retail';
    end
    if ismember('ResampleBin', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleBin', varargin), 1);
        bin = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        bin = 'none';
    end
    if ismember('ResampleMethod', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleMethod', varargin), 1);
        method = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        method = 'mean';
    end
    
    if ~ismember('DisplayName', varargin(1:2:length(varargin)))
        varargin = [varargin(:)', {'DisplayName'}, strcat(market, '-', suf)];
    end
    
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    
    filename = strcat(market, '_', suf, '_patterns');
    t = basic_read(filename);
    t = t(ismember(t.date, date_range),:);
    t = basic_resample(t, bin, method);
    
    
    p = plot_line_chart(t(:, {'date', sector}), varargin{:});
    sector = replace(sector, "_", " ");
    ylabel(strcat(sector, ' Mobility'));
end
