function gr_handles = plot_baseline(market, varargin)
    if ismember('Method', varargin(1:2:length(varargin)))
        index = find(strcmp('Method', varargin), 1);
        methods = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        methods = ["backcast", "date", "week"];
    end
    if ismember('ResampleBin', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleBin', varargin), 1);
        bin = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        bin = 'none';
    end
    if ismember('ResampleMethod', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleMethod', varargin), 1);
        method = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        method = 'mean';
    end
    if ischar(methods)
       methods = string(methods); 
    end
    
    gr_handles = {};
    for baseline_method = methods
        t_output = cal_baseline(market, varargin{:}, 'Method', baseline_method);
        if strcmp(t_output.Properties.VariableNames{1}, 'date')
            t = basic_plot_preprocess_table(t_output, bin, method);
            p = plot_line_chart(t, varargin{:}, 'DisplayName', strcat("by ",baseline_method));
            gr_handles = [gr_handles, p];
        else
            t_plot = basic_plot_preprocess_table(t_output{1,2}, bin, method);
            t_plot = renamevars(t_plot, 2, strcat("q=",num2str(t_output{1,1}, '%.2f')));
            for k = 2:height(t_output)
               t = basic_plot_preprocess_table(t_output{k,2}, bin, method);
               t_plot = addvars(t_plot, t{:,2}, 'NewVariableNames', strcat("q=",num2str(t_output{k,1}, '%.2f')));
            end
            ar = plot_quantile(t_plot);
            gr_handles = [gr_handles, ar];
        end
    end
    ylabel('Electricity Demand (MW)');
end