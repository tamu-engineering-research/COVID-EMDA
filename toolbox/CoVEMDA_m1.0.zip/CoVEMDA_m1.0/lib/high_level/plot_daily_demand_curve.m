function gr_handles = plot_daily_demand_curve(market, varargin)
    % GR_HANDLES = plot_daily_demand_curve(MARKET, VARARGIN)
    %
    % Description:
    % 	Plot the daily demand distribution curve of the specified date range.
    %
    % Input:
    %   VARARGIN: DATERANGE: Date range. Default {'2017-01-01',
    %                        '2020-07-15'}.
    %             QUANTILE: Quantiles to be calculated. Default [0.05,
    %                       0.25, 0.5, 0.75, 0.95].
    %             Others: See also plot_quantile.
    %
    % Example:
    %   plot_daily_demand_curve('nyiso', 'DateRange', {'2018-02-01',
    %                           '2018-02-28'});
    %   plot_daily_demand_curve('nyiso', 'DateRange', {'2018-02-01',
    %                           '2018-02-28'}, 'Quantile',
    %                            [0.05, 0.25, 0.5, 0.75, 0.95]);
    %   plot_daily_demand_curve('nyiso', 'DateRange', {'2018-02-01',
    %                           '2018-02-28'}, 'Color', '#0072BD',
    %                           'Alpha', [0.1, 0.25], 'LineWidth', 2.5);
    
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = {'2017-01-01', '2020-07-15'};
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    if ismember('Quantile', varargin(1:2:length(varargin)))
        index = find(strcmp('Quantile', varargin), 1);
        q = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        q = [0.05, 0.25, 0.5, 0.75, 0.95];
    end
    
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    
    filename = strcat(market, '_', suf, '_load');
    t = basic_read(filename);
    t = t(ismember(t.date, date_range),:);
    other_headers = {'date', 'fuel'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers);
    t_q = array2table(quantile(t{:, calc_val}, q)', 'VariableNames', strcat("q=",string(q)));
    t_q = addvars(t_q, string(calc_val)', 'Before', 1, 'NewVariableNames', 'time');
    
    gr_handles = plot_quantile(t_q, varargin{:});
    ylabel('Electricity Demand (MW)');
end
