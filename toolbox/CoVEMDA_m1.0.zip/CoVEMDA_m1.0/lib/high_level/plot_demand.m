function p = plot_demand(market, varargin)
    % P = plot_demand(MARKET, VARARGIN)
    %
    % Description:
    % 	Plot the demand curve of the specified date range.
    %
    % Input:
    %   VARARGIN: DATERANGE: Date range. Default {'2017-01-01', '2020-07-15'}.
    %             RESAMPLEBIN: The bin to resample data. Default 'none'.
    %             RESAMPLEMETHOD: The method to resample data. Default 'mean'.
    %             Others: See also plot_line_chart.
    %
    % Example:
    %   plot_demand('nyiso');
    %   plot_demand('nyiso', 'DateRange', {'2020-02-01', '2020-04-30'});
    %   plot_demand('nyiso', 'DateRange', {'2017-01-01', '2020-07-15'},
    %               'ResampleBin', 'month', 'ResampleMethod', 'sum');
    %   plot_demand('nyiso', 'DateRange', {'2020-02-01', '2020-04-30'},
    %               'DisplayName', '2020', 'LineStyle', '-', 'Color', '#0072BD', 'LineWidth', 2.5);
    
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = {'2017-01-01', '2020-07-15'};
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    if ismember('ResampleBin', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleBin', varargin), 1);
        bin = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        bin = 'none';
    end
    if ismember('ResampleMethod', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleMethod', varargin), 1);
        method = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        method = 'mean';
    end
    
    if ~ismember('DisplayName', varargin(1:2:length(varargin)))
        varargin = [varargin(:)', {'DisplayName'}, strcat(market, '-', suf)];
    end
    
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    
    filename = strcat(market, '_', suf, '_load');
    t = basic_read(filename);
    t = t(ismember(t.date, date_range),:);
    t = basic_plot_preprocess_table(t, bin, method);
    
    p = plot_line_chart(t, varargin{:});
    ylabel('Electricity Demand (MW)');
end
