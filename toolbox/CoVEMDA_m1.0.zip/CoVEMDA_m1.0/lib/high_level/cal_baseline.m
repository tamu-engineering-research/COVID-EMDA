function t_output = cal_baseline(market, varargin)
    if ismember('Method', varargin(1:2:length(varargin)))
        index = find(strcmp('Method', varargin), 1);
        method = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        method = 'backcast';
    end
    if ismember('DateRangeCovid', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRangeCovid', varargin), 1);
        dr_Covid = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        dr_Covid = datetime('2020-02-01'):datetime('2020-06-30');
    end
    if ~isdatetime(dr_Covid)
        dr_Covid = datetime(dr_Covid);
    end
    if length(dr_Covid) == 2
        dr_Covid = dr_Covid(1):dr_Covid(2);
    end
    
    if strcmp(method, 'date')
        t_output = cal_baseline_by_dates(market, dr_Covid, varargin{:});
    elseif strcmp(method, 'week')
        t_output = cal_baseline_by_week_index(market, dr_Covid, varargin{:});
    else
        t_output = cal_baseline_by_backcast(market, dr_Covid, varargin{:});
    end
end