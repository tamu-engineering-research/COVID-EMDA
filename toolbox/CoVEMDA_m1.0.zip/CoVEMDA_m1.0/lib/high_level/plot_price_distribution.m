function H = plot_price_distribution(market, varargin)
    % H = plot_price_distribution(MARKET, VARARGIN)
    %
    % Description:
    % 	Plot the price distribution of the specified date range.
    %
    % Input:
    %   VARARGIN: DATERANGE: Date range. Default {'2017-01-01',
    %                        '2020-07-15'}.
    %             Others: See also plot_histogram.
    %
    % Example:
    %   plot_price_distribution('isone');
    %   plot_price_distribution('isone', 'DateRange', {'2017-03-01', '2017-07-31'});
    
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = {'2017-01-01', '2020-07-15'};
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    if ~ismember('DisplayName', varargin(1:2:length(varargin)))
        varargin = [varargin(:)', {'DisplayName'}, strcat(market, '-', suf)];
    end
    
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    
    filename = strcat(market, '_', suf, '_lmp');
    t = basic_read(filename);
    t = t(ismember(t.date, date_range),:);
    other_headers = {'date'};
    calc_val = setdiff(t.Properties.VariableNames, other_headers);
    t = stack(t, calc_val, 'NewDataVariableName', 'lmp');
    t.lmp_Indicator = [];
    
    H = plot_histogram(t, varargin{:});
    xlabel('Day-Ahead Locational Marginal Price ($/MW)');
    ylabel('Occurence Frequency');
end
