function ar = plot_generation_mix(market, varargin)
    % AR = plot_generation_mix(MARKET, VARARGIN)
    %
    % Description:
    % 	Plot the generation mix of the specified date range.
    %
    % Input:
    %   VARARGIN: DATERANGE: Date range. Default {'2017-01-01',
    %                        '2020-07-15'}.
    %             RESAMPLEBIN: The bin to resample data. Default 'month'.
    %             Others: See also plot_area.
    %
    % Example:
    %   plot_generation_mix('spp');
    %   plot_generation_mix('spp', 'DateRange', {'2017-01-01',
    %                       '2020-07-15'}, 'ResampleBin', 'month');
    %   plot_generation_mix('spp', 'DateRange', {'2017-01-01',
    %                       '2020-07-15'}, 'ResampleBin', 'month', 'ColorMap', ColorMap);
    %   plot_generation_mix('spp', 'DateRange', {'2017-01-01',
    %                       '2020-07-15'}, 'ResampleBin', 'month', 'FaceAlpha', 0.5);
    
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = {'2017-01-01', '2020-07-15'};
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    if ismember('ResampleBin', varargin(1:2:length(varargin)))
        index = find(strcmp('ResampleBin', varargin), 1);
        bin = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        bin = 'month';
    end
    
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    filename = strcat(market, '_', suf, '_genmix');
    t = basic_read(filename);
    t = t(ismember(t.date, date_range),:);
    t = basic_resample(basic_sum(t, 1), bin, 'mean');
    t_kinds = unstack(t, '00:00', 'fuel');
    t_kinds.date = string(t_kinds.date);
    
    ar = plot_area(t_kinds, varargin{:});
    ylabel('Generation Mix(%)');
end