function output = cal_excess_change_rate(market, varargin)
    if ismember('DateRange', varargin(1:2:length(varargin)))
        index = find(strcmp('DateRange', varargin), 1);
        date_range = varargin{index+1};
        varargin([index, index+1]) = [];
    else
        date_range = datetime('2017-01-01'):datetime('2020-07-15');
    end
    if ismember('City', varargin(1:2:length(varargin)))
        index = find(strcmp('City', varargin), 1);
        suf = varargin{index+1};
    else
        suf = 'rto';
    end
    if ~isdatetime(date_range)
        date_range = datetime(date_range);
    end
    if length(date_range) == 2
        date_range = date_range(1):date_range(2);
    end
    
    col_renewable = {'wind', 'solar'};
    
    filename = strcat(market, '_', suf, '_genmix');
    t = basic_read(filename);
    t = t(ismember(t.date, date_range),:);
    
    t_renewable = t(ismember(t.fuel, col_renewable),:);
    t_gensum = basic_group(basic_sum(t, 1), 'sum');
    t_gensum = basic_resample(t_gensum, 'year', 'mean');
    t_renewable = basic_group(basic_sum(t_renewable, 1), 'sum');
    t_renewable = basic_resample(t_renewable, 'year', 'mean');
    
    t_excess = basic_calc(t_renewable, t_gensum, 'div');
    output = t_excess{strcmp(t_excess.date,"2020"),2}/(2*t_excess{strcmp(t_excess.date,"2019"),2} - t_excess{strcmp(t_excess.date,"2018"),2});
    output = (output - 1) * 100;
end