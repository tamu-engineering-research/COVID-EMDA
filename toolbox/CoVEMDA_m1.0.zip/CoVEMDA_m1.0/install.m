function install
    rootdir = mfilename('fullpath');
    filename_length = length(mfilename());
    rootdir(end-filename_length:end) = [];
    disp("Installing CoVEMDA.");
    alldir = genpath(strcat(rootdir, '\lib'));
    addpath(alldir, '-end');
    
    disp("--Checking dependencies ...");
    [~,CoVEMDA_dependencies] = matlab.codetools.requiredFilesAndProducts(cellstr(ls(strcat(rootdir,'\lib\high_level\*.m'))));
    CoVEMDA_dependencies = struct2table(CoVEMDA_dependencies);
    CoVEMDA_dependencies = CoVEMDA_dependencies(:,{'Name','Version'})
    
    Name = {'matlab','nnet','stats','finance'}';
    Version = {'9.8','14.0','11.7','5.15'}';
    dep = table(Name, Version);
    for k = 1:height(dep)
        if verLessThan(dep.Name{k},dep.Version{k})
            error(strcat(dep.Name{k}," ",dep.Version{k}," or higher is required."));
        end
    end
    disp("--Dependencies check complete.");
    
    savepath;
    disp("Installation complete.");
end